package com.egsoftware.departament.service;

import com.egsoftware.departament.entity.Departament;
import com.egsoftware.departament.repository.DepartamentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DepartamentService {

    @Autowired
    private DepartamentRepository departamentRepository;

    public Departament saveDepartament(Departament departament){
        return departamentRepository.save(departament);
    }

    public Departament findByDepartamentId(Long departamentId){
        return departamentRepository.findByDepartamentId(departamentId);
    }
}
