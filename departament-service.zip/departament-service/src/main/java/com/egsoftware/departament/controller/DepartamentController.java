package com.egsoftware.departament.controller;

import com.egsoftware.departament.entity.Departament;
import com.egsoftware.departament.service.DepartamentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/departaments")
public class DepartamentController {

    @Autowired
    private DepartamentService departamentService;

    @PostMapping("/")
    public Departament saveDepartament(@RequestBody Departament departament){
        return departamentService.saveDepartament(departament);
    }

    @GetMapping("/{id}")
    public Departament findByDepartamentId(@PathVariable("id") Long departamentId){
        return departamentService.findByDepartamentId(departamentId);
    }

}
