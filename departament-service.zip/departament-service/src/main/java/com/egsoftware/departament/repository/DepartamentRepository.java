package com.egsoftware.departament.repository;

import com.egsoftware.departament.entity.Departament;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DepartamentRepository extends JpaRepository<Departament, Long> {
    Departament findByDepartamentId(Long departamentID);
}
